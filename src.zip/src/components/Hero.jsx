import { useTypewriter } from "../hooks/useAnimations";
import GridCanvas from "./GridCanvas";
import styles from "./Hero.module.css";

export default function Hero() {
  const typed = useTypewriter([
    "Software Developer",
    "Backend Engineer",
    "Competitive Programmer",
    "Full Stack Builder",
  ]);

  const scrollTo = (id) => {
    document.getElementById(id)?.scrollIntoView({ behavior: "smooth" });
  };

  return (
    <section id="about" className={styles.hero}>
      <GridCanvas />
      <div className={styles.content}>
        <p className={`${styles.eyebrow} anim-eyebrow`}>Based in Prayagraj, India</p>
        <h1 className={`${styles.name} anim-name`}>
          Saumya<br />Keservani
        </h1>
        <div className={`${styles.typedRow} anim-typed`}>
          <span>{typed}</span>
          <span className="cursor" />
        </div>
        <p className={`${styles.desc} anim-desc`}>
          B.Tech CSE graduate building distributed banking systems at TCS. Specialist on
          Codeforces, Knight on LeetCode, 2000+ problems solved — algorithmic thinking at
          every layer of the stack.
        </p>
        <div className={`${styles.btns} anim-btns`}>
          <button className={styles.btnPrimary} onClick={() => scrollTo("experience")}>
            View Experience
          </button>
          <button className={styles.btnOutline} onClick={() => scrollTo("contact")}>
            Get in Touch
          </button>
        </div>
      </div>
    </section>
  );
}
