import { SKILLS, ACHIEVEMENTS } from "../data/portfolioData";
import Reveal from "./Reveal";
import SectionHeader from "./SectionHeader";
import styles from "./Skills.module.css";

export default function Skills() {
  return (
    <section id="skills" className={styles.section}>
      <Reveal>
        <SectionHeader label="What I work with" title="Skills" />
      </Reveal>

      <div className={styles.skillsGrid}>
        {Object.entries(SKILLS).map(([category, items], i) => (
          <Reveal key={category} delay={i * 0.08}>
            <div className={styles.skillCard}>
              <p className={styles.category}>{category}</p>
              {items.map((skill) => (
                <div key={skill} className={styles.skillItem}>{skill}</div>
              ))}
            </div>
          </Reveal>
        ))}
      </div>

      <Reveal>
        <div className={styles.achieveHeader}>
          <p className={styles.achieveLabel}>Competitive Programming</p>
          <h3 className={styles.achieveTitle}>Achievements</h3>
        </div>
      </Reveal>

      <div className={styles.achieveGrid}>
        {ACHIEVEMENTS.map((a, i) => (
          <Reveal key={a.label} delay={i * 0.07}>
            <div
              className={styles.achieveCard}
              style={{ borderLeftColor: a.color }}
            >
              <p className={styles.achieveCardLabel}>{a.label}</p>
              <p className={styles.achieveCardValue} style={{ color: a.color }}>
                {a.value}
              </p>
            </div>
          </Reveal>
        ))}
      </div>
    </section>
  );
}
