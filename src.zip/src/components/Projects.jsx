import { PROJECTS } from "../data/portfolioData";
import Reveal from "./Reveal";
import SectionHeader from "./SectionHeader";
import styles from "./Projects.module.css";

export default function Projects() {
  return (
    <section id="projects" className={styles.section}>
      <Reveal>
        <SectionHeader label="Things I've built" title="Projects" />
      </Reveal>

      <div className={styles.grid}>
        {PROJECTS.map((proj, i) => (
          <Reveal key={proj.name} delay={i * 0.1}>
            <div className={styles.card}>
              <h3 className={styles.name}>{proj.name}</h3>
              <p className={styles.desc}>{proj.desc}</p>
              <div className={styles.tags}>
                {proj.tech.map((t) => (
                  <span key={t} className={styles.tag}>{t}</span>
                ))}
              </div>
              <div className={styles.links}>
                <a href={proj.link} target="_blank" rel="noreferrer" className={styles.linkBtn}>
                  Live ↗
                </a>
                <a href={proj.github} target="_blank" rel="noreferrer" className={styles.linkBtn}>
                  GitHub ↗
                </a>
              </div>
            </div>
          </Reveal>
        ))}
      </div>
    </section>
  );
}
