import { useState } from "react";
import { NAV_LINKS } from "../data/portfolioData";
import { useScrolled } from "../hooks/useAnimations";
import styles from "./Navbar.module.css";

export default function Navbar() {
  const [menuOpen, setMenuOpen] = useState(false);
  const scrolled = useScrolled();

  const scrollTo = (id) => {
    document.getElementById(id.toLowerCase())?.scrollIntoView({ behavior: "smooth" });
    setMenuOpen(false);
  };

  return (
    <>
      <nav className={`${styles.nav} ${scrolled ? styles.navScrolled : ""}`}>
        <div className={styles.logo} onClick={() => scrollTo("about")}>SK.</div>

        <ul className={styles.navLinks}>
          {NAV_LINKS.map((link) => (
            <li key={link} className={styles.navLink} onClick={() => scrollTo(link)}>
              {link}
            </li>
          ))}
        </ul>

        <button
          className={styles.hamburger}
          onClick={() => setMenuOpen(!menuOpen)}
          aria-label="Toggle menu"
        >
          <span className={styles.bar} />
          <span className={styles.bar} />
          <span className={styles.bar} />
        </button>
      </nav>

      {menuOpen && (
        <div className={styles.mobileMenu}>
          {NAV_LINKS.map((link) => (
            <div key={link} className={styles.mobileLink} onClick={() => scrollTo(link)}>
              {link}
            </div>
          ))}
        </div>
      )}
    </>
  );
}
