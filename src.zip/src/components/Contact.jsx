import { CONTACT_LINKS } from "../data/portfolioData";
import Reveal from "./Reveal";
import styles from "./Contact.module.css";

export default function Contact() {
  return (
    <section id="contact" className={styles.section}>
      <Reveal>
        <p className={styles.label}>Let's connect</p>
        <h2 className={styles.title}>Get in Touch</h2>
        <p className={styles.desc}>
          Open to new opportunities, collaborations, or just a chat about competitive
          programming. My inbox is always open.
        </p>
      </Reveal>

      <Reveal delay={0.15}>
        <div className={styles.links}>
          {CONTACT_LINKS.map((c) => (
            <a
              key={c.label}
              href={c.href}
              className={styles.link}
              target={c.href.startsWith("mailto") ? "_self" : "_blank"}
              rel="noreferrer"
            >
              <span className={styles.icon}>{c.icon}</span>
              {c.label}
            </a>
          ))}
        </div>
      </Reveal>
    </section>
  );
}
