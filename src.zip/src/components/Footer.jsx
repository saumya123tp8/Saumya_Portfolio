import styles from "./Footer.module.css";

export default function Footer() {
  return (
    <footer className={styles.footer}>
      Designed &amp; built by Saumya Keservani · {new Date().getFullYear()}
    </footer>
  );
}
