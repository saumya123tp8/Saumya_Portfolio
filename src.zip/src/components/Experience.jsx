import { EXPERIENCE } from "../data/portfolioData";
import Reveal from "./Reveal";
import SectionHeader from "./SectionHeader";
import styles from "./Experience.module.css";

export default function Experience() {
  return (
    <section id="experience" className={styles.section}>
      <Reveal>
        <SectionHeader label="Where I've worked" title="Experience" />
      </Reveal>

      {EXPERIENCE.map((exp, i) => (
        <Reveal key={exp.company} delay={i * 0.12}>
          <div className={styles.card}>
            <div className={styles.cardHeader}>
              <div>
                <h3 className={styles.company}>{exp.company}</h3>
                <p className={styles.role}>{exp.role} · {exp.type}</p>
              </div>
              <span className={styles.period}>{exp.period}</span>
            </div>
            <ul className={styles.points}>
              {exp.points.map((point, j) => (
                <li key={j} className={styles.point}>
                  <span className={styles.bullet}>▶</span>
                  <span>{point}</span>
                </li>
              ))}
            </ul>
          </div>
        </Reveal>
      ))}
    </section>
  );
}
