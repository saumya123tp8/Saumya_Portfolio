export const NAV_LINKS = ["About", "Experience", "Projects", "Skills", "Contact"];

export const EXPERIENCE = [
  {
    company: "TCS",
    role: "Software Developer",
    period: "Sep 2024 – Present",
    type: "In-Office",
    points: [
      "Engineered and deployed 20+ production features, resolving high-priority defects and improving system stability.",
      "Implemented Master Settlement Account feature, reducing direct transactions by 40% and improving efficiency.",
      "Migrated 20+ MT messages to ISO 20022 MX format, introducing 100+ attributes for high-value transaction processing.",
      "Designed and developed 10+ Java Spring Boot microservices using Kafka-based messaging for distributed banking services.",
    ],
  },
  {
    company: "AgiledCoders",
    role: "Software Developer Intern",
    period: "Jun 2024 – Aug 2024",
    type: "Remote",
    points: [
      "Delivered 30% of core website features, resolved critical bugs, and improved SEO performance.",
      "Developed and optimized applications using React.js, Node.js, and PL/SQL; containerized services using Docker.",
      "Owned project execution and task coordination, leading a 3-member intern team ensuring 100% on-time delivery.",
      "Enhanced UI/UX across 10+ screens in an Agile environment, improving overall user experience.",
    ],
  },
];

export const PROJECTS = [
  {
    name: "AmbanICoffee",
    desc: "Full-stack food delivery platform supporting authentication, authorization, and order management with PayPal and Braintree payment gateways.",
    tech: ["React.js", "Node.js", "Express.js", "MongoDB", "Bootstrap"],
    link: "#",
    github: "#",
  },
  {
    name: "Ooops Post",
    desc: "Full-featured blog application supporting post creation, updates, likes, comments, and favorites. Increased user engagement by 60%.",
    tech: ["React.js", "Node.js", "Express.js", "MongoDB", "Material UI"],
    link: "#",
    github: "#",
  },
];

export const SKILLS = {
  Languages: ["C++", "Java", "JavaScript"],
  Frontend: ["React.js", "Bootstrap", "HTML", "CSS", "Material UI"],
  "Backend & DB": ["Spring Boot", "Spring AI", "Node.js", "Kafka", "MongoDB", "SQL"],
  "Tools & APIs": ["Git", "Docker", "Postman", "Swagger", "SOAP/RESTful API"],
  "Core CS": ["System Design (HLD/LLD)", "DBMS", "OOP (C++/Java)"],
};

export const ACHIEVEMENTS = [
  { label: "Codeforces", value: "Specialist · 1470", color: "#5C6BFF" },
  { label: "CodeChef", value: "4★ · 1835", color: "#A78BFA" },
  { label: "LeetCode", value: "Knight · 1942", color: "#38BDF8" },
  { label: "CodeVita S11", value: "Global Rank 251 · Top 1%", color: "#34D399" },
  { label: "CodeKaze Sep'23", value: "AIR 139 / 30k+", color: "#FB923C" },
  { label: "Problems Solved", value: "2000+", color: "#F472B6" },
];

export const CONTACT_LINKS = [
  { label: "Email", icon: "✉", href: "mailto:saumyakesarvani6475@gmail.com" },
  { label: "LinkedIn", icon: "in", href: "https://linkedin.com/in/YOUR_USERNAME" },
  { label: "GitHub", icon: "⌥", href: "https://github.com/YOUR_USERNAME" },
  { label: "LeetCode", icon: "⟨⟩", href: "https://leetcode.com/YOUR_USERNAME" },
  { label: "Codeforces", icon: "⊕", href: "https://codeforces.com/profile/YOUR_USERNAME" },
];
